<?php
require_once __DIR__ . '/config/config.php';
require_login();

$pageTitle = 'Dashboard';
include __DIR__ . '/includes/header.php';
?>
<h2>Dashboard</h2>
<p class="text-muted">Welcome back, <?= htmlspecialchars($_SESSION['full_name']) ?>! You are securely logged in.</p>

<div class="card mt-4">
  <div class="card-body">
    <h5 class="card-title">Your session</h5>
    <ul class="mb-0">
      <li>Username: <?= htmlspecialchars($_SESSION['username']) ?></li>
      <li>Logged in since: current session</li>
    </ul>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
