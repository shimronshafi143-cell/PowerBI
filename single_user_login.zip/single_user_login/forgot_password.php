<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/mail/mailer.php';

$errors  = [];
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        $errors[] = 'Invalid form submission. Please try again.';
    } else {
        $username = clean_input($_POST['username'] ?? '');

        if ($username === '') {
            $errors[] = 'Please enter your username.';
        } else {
            $stmt = $pdo->prepare('SELECT id, full_name FROM users WHERE username = :u LIMIT 1');
            $stmt->execute([':u' => $username]);
            $user = $stmt->fetch();

            // Same message whether or not the username exists - avoids
            // confirming to an attacker that this account is the one in use.
            $success = 'If that username exists, a reset link has been generated. Check mail/outbox.log.';

            if ($user) {
                $rawToken  = bin2hex(random_bytes(32));
                $tokenHash = hash('sha256', $rawToken); // store hash only, never the raw token
                $expiresAt = date('Y-m-d H:i:s', strtotime('+' . RESET_TOKEN_EXPIRY_MIN . ' minutes'));

                $stmt = $pdo->prepare(
                    'INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (:uid, :hash, :exp)'
                );
                $stmt->execute([':uid' => $user['id'], ':hash' => $tokenHash, ':exp' => $expiresAt]);

                $resetLink = BASE_URL . 'reset_password.php?token=' . $rawToken;
                send_mail_stub(
                    $username . ' (local account)',
                    'Password Reset - ' . APP_NAME,
                    "Hi {$user['full_name']},<br><br>Click below to reset your password:<br>" .
                    "<a href=\"{$resetLink}\">{$resetLink}</a><br><br>This link expires in " .
                    RESET_TOKEN_EXPIRY_MIN . " minutes. If you didn't request this, ignore it."
                );
            }
        }
    }
}

$pageTitle = 'Forgot Password';
include __DIR__ . '/includes/header.php';
?>
<div class="row justify-content-center">
  <div class="col-md-5">
    <div class="card shadow-sm">
      <div class="card-body p-4">
        <h3 class="mb-4 text-center">Forgot Password</h3>

        <?php if ($success): ?>
          <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        <?php foreach ($errors as $error): ?>
          <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endforeach; ?>

        <form method="POST" action="forgot_password.php">
          <?= csrf_field() ?>
          <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" name="username" class="form-control" required>
          </div>
          <button type="submit" class="btn btn-primary w-100">Send Reset Link</button>
        </form>

        <p class="text-center mt-3 mb-0"><a href="login.php">Back to Login</a></p>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
