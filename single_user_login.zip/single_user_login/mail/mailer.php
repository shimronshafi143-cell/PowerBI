<?php
/**
 * Minimal mail helper - used only for password-reset links.
 * XAMPP can't send real mail out of the box, so the "email" is written
 * to mail/outbox.log. Open that file, copy the link, and paste it into
 * your browser. Swap this for PHPMailer + SMTP for a live deployment.
 */
function send_mail_stub(string $to, string $subject, string $bodyHtml): void
{
    $logFile = __DIR__ . '/outbox.log';
    $entry  = "\n----- " . date('Y-m-d H:i:s') . " -----\n";
    $entry .= "To: {$to}\nSubject: {$subject}\n\n{$bodyHtml}\n";
    file_put_contents($logFile, $entry, FILE_APPEND);
}
