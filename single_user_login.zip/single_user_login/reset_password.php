<?php
require_once __DIR__ . '/config/config.php';

$errors  = [];
$token   = $_GET['token'] ?? ($_POST['token'] ?? '');
$validToken = false;
$resetRecord = null;

if ($token !== '') {
    $tokenHash = hash('sha256', $token);
    $stmt = $pdo->prepare(
        'SELECT * FROM password_resets WHERE token_hash = :h AND used = 0 LIMIT 1'
    );
    $stmt->execute([':h' => $tokenHash]);
    $resetRecord = $stmt->fetch();

    if ($resetRecord && strtotime($resetRecord['expires_at']) >= time()) {
        $validToken = true;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        $errors[] = 'Invalid form submission. Please try again.';
    } elseif (!$validToken) {
        $errors[] = 'This reset link is invalid or has expired.';
    } else {
        $password = $_POST['password'] ?? '';
        $confirm  = $_POST['confirm_password'] ?? '';

        if (!is_strong_password($password)) {
            $errors[] = 'Password must be at least 8 characters and include a letter and a number.';
        } elseif ($password !== $confirm) {
            $errors[] = 'Passwords do not match.';
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);

            $pdo->prepare('UPDATE users SET password = :p WHERE id = :id')
                ->execute([':p' => $hashed, ':id' => $resetRecord['user_id']]);

            // Single-use token
            $pdo->prepare('UPDATE password_resets SET used = 1 WHERE id = :id')
                ->execute([':id' => $resetRecord['id']]);

            set_flash('success', 'Password reset successful. Please log in with your new password.');
            redirect('login.php');
        }
    }
}

$pageTitle = 'Reset Password';
include __DIR__ . '/includes/header.php';
?>
<div class="row justify-content-center">
  <div class="col-md-5">
    <div class="card shadow-sm">
      <div class="card-body p-4">
        <h3 class="mb-4 text-center">Reset Password</h3>

        <?php foreach ($errors as $error): ?>
          <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endforeach; ?>

        <?php if (!$validToken): ?>
          <div class="alert alert-warning">
            Invalid or expired link. <a href="forgot_password.php">Request a new one</a>.
          </div>
        <?php else: ?>
          <form method="POST" action="reset_password.php">
            <?= csrf_field() ?>
            <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">

            <div class="mb-3">
              <label class="form-label">New Password</label>
              <input type="password" name="password" class="form-control" required minlength="8">
            </div>
            <div class="mb-3">
              <label class="form-label">Confirm New Password</label>
              <input type="password" name="confirm_password" class="form-control" required minlength="8">
            </div>
            <button type="submit" class="btn btn-primary w-100">Reset Password</button>
          </form>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
