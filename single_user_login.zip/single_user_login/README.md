# Single-User Secure Login System (PHP + MySQL + Bootstrap + XAMPP)

No registration page, no email verification — this system has exactly
**one** user account, pre-seeded in the database. This matches your
last request: keep the security layers, drop multi-user/email-verify
overhead.

## 1. Setup (XAMPP)

1. Copy the `single_user_login` folder into `C:\xampp\htdocs\`.
2. Start **Apache** and **MySQL**.
3. In phpMyAdmin, import `database.sql`. It creates `single_user_login_db`
   with one seeded account:
   - Username: `admin`
   - Password: `Admin@123`
4. Change `BASE_URL` in `config/config.php` to match your local path.
5. Log in at `http://localhost/single_user_login/login.php`, then
   **change the seeded password** using "Forgot password?" (or update
   it directly in the database with a new `password_hash()` value).

## 2. Why "forgot password" still works without email

Since there's no email column, the reset flow is keyed off the
username instead. XAMPP can't send real email out of the box, so the
reset link is written to `mail/outbox.log` — open that file, copy the
link, and paste it into your browser. Swap `send_mail_stub()` in
`mail/mailer.php` for PHPMailer + SMTP if you ever deploy this live.

## 3. Security layers kept from your original list

| Requirement | Where |
|---|---|
| Password hashing | `password_hash()` in `database.sql` seed / `reset_password.php` |
| Password verification | `password_verify()` in `login.php` |
| Prepared statements | Every query uses PDO bound parameters |
| Session security | `config/config.php`: HttpOnly, SameSite, idle timeout |
| Session regeneration | `session_regenerate_id(true)` after login |
| Input validation | `clean_input()`, `is_strong_password()` in `includes/functions.php` |
| CSRF protection | `includes/csrf.php`, checked on every POST |
| Login attempt limit | `login_attempts` table, 5 tries / 15-min lockout |
| Forgot password | `forgot_password.php` + `reset_password.php`, SHA-256-hashed single-use token, 30-min expiry |
| Logout security | `logout.php` clears session + expires cookie |
| HTTPS-aware | Cookie `secure` flag auto-enables when served over HTTPS |
| Secure cookies | `session_set_cookie_params()` — HttpOnly, SameSite=Lax |
| Generic error message | `login.php` never says which field was wrong |

**Dropped on purpose:** registration page, email verification, and
role-based access — not needed for a single fixed account.

## 4. Folder structure

```
single_user_login/
├── config/
│   ├── config.php
│   ├── db.php
│   └── .htaccess
├── includes/
│   ├── csrf.php
│   ├── functions.php
│   ├── header.php
│   └── footer.php
├── mail/
│   ├── mailer.php
│   └── outbox.log
├── database.sql
├── login.php
├── forgot_password.php
├── reset_password.php
├── logout.php
└── dashboard.php
```
