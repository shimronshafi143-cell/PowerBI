<?php
/**
 * Global configuration + secure session bootstrap.
 * Include this file FIRST on every page (before any output).
 */

define('APP_NAME', 'Secure Login');
define('BASE_URL', 'http://localhost/single_user_login/'); // change for your setup

define('MAX_LOGIN_ATTEMPTS', 5);       // failed attempts allowed
define('LOCKOUT_MINUTES', 15);         // lockout duration after max attempts
define('RESET_TOKEN_EXPIRY_MIN', 30);  // password reset link validity

// ---- Secure session cookie settings (must run before session_start) ----
if (session_status() === PHP_SESSION_NONE) {
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'domain'   => '',
        'secure'   => $isHttps,   // becomes true automatically on HTTPS
        'httponly' => true,       // JS cannot read the cookie
        'samesite' => 'Lax',
    ]);

    session_name('SUL_SESSID');
    session_start();
}

// ---- Idle session timeout (30 minutes) ----------------------------------
$SESSION_TIMEOUT = 1800;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $SESSION_TIMEOUT) {
    session_unset();
    session_destroy();
    header('Location: login.php?timeout=1');
    exit;
}
$_SESSION['last_activity'] = time();

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/csrf.php';
