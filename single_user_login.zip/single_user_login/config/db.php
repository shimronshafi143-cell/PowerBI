<?php
/**
 * Database connection (PDO)
 * Update credentials to match your XAMPP MySQL setup.
 */

$DB_HOST = 'localhost';
$DB_NAME = 'single_user_login_db';
$DB_USER = 'root';
$DB_PASS = ''; // default XAMPP MySQL password is empty

try {
    $pdo = new PDO(
        "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    error_log('DB Connection Error: ' . $e->getMessage());
    die('Database connection failed. Please try again later.');
}
