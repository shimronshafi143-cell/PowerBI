<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? htmlspecialchars($pageTitle) . ' - ' : '' ?><?= APP_NAME ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="<?= is_logged_in() ? 'dashboard.php' : 'login.php' ?>"><?= APP_NAME ?></a>
    <?php if (is_logged_in()): ?>
      <div class="d-flex align-items-center">
        <span class="text-white me-3"><?= htmlspecialchars($_SESSION['full_name']) ?></span>
        <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
      </div>
    <?php endif; ?>
  </div>
</nav>
<div class="container py-5">
