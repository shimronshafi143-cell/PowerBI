<?php
function clean_input(string $data): string
{
    $data = trim($data);
    $data = stripslashes($data);
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

function is_strong_password(string $password): bool
{
    return (bool) preg_match('/^(?=.*[A-Za-z])(?=.*\d).{8,}$/', $password);
}

function set_flash(string $type, string $message): void
{
    $_SESSION['flash'][$type] = $message;
}

function get_flash(string $type): ?string
{
    if (!empty($_SESSION['flash'][$type])) {
        $msg = $_SESSION['flash'][$type];
        unset($_SESSION['flash'][$type]);
        return $msg;
    }
    return null;
}

function redirect(string $path): void
{
    header('Location: ' . $path);
    exit;
}

function is_logged_in(): bool
{
    return !empty($_SESSION['user_id']);
}

function require_login(): void
{
    if (!is_logged_in()) {
        redirect('login.php');
    }
}

function client_ip(): string
{
    return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
}

function get_recent_failed_attempts(PDO $pdo, string $username, string $ip): int
{
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) AS attempts FROM login_attempts
         WHERE username = :username AND ip_address = :ip
           AND success = 0
           AND attempted_at > (NOW() - INTERVAL :mins MINUTE)"
    );
    $stmt->execute([
        ':username' => $username,
        ':ip'       => $ip,
        ':mins'     => LOCKOUT_MINUTES,
    ]);
    return (int) $stmt->fetch()['attempts'];
}

function log_login_attempt(PDO $pdo, string $username, string $ip, bool $success): void
{
    $stmt = $pdo->prepare(
        "INSERT INTO login_attempts (username, ip_address, success) VALUES (:u, :ip, :s)"
    );
    $stmt->execute([':u' => $username, ':ip' => $ip, ':s' => $success ? 1 : 0]);
}

function clear_login_attempts(PDO $pdo, string $username, string $ip): void
{
    $stmt = $pdo->prepare(
        "DELETE FROM login_attempts WHERE username = :u AND ip_address = :ip"
    );
    $stmt->execute([':u' => $username, ':ip' => $ip]);
}
