-- ===================================================================
-- Single-User Secure Login System - Database Schema
-- Import in phpMyAdmin (XAMPP) before running the app.
-- No registration page - only ONE user exists (created below).
-- ===================================================================

CREATE DATABASE IF NOT EXISTS single_user_login_db
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE single_user_login_db;

-- ---------------------------------------------------------------
-- Single user account
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    full_name   VARCHAR(100)  NOT NULL,
    username    VARCHAR(50)   NOT NULL UNIQUE,
    password    VARCHAR(255)  NOT NULL,   -- password_hash() output
    created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
                               ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------
-- Password reset tokens
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS password_resets (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    token_hash  VARCHAR(255) NOT NULL,   -- SHA-256 hash of the raw token
    expires_at  DATETIME NOT NULL,
    used        TINYINT(1) NOT NULL DEFAULT 0,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------
-- Login attempts (rate limiting / temporary lockout)
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS login_attempts (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    username     VARCHAR(50)  NOT NULL,
    ip_address   VARCHAR(45)  NOT NULL,
    success      TINYINT(1)   NOT NULL DEFAULT 0,
    attempted_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------
-- The one and only user (username: admin / password: Admin@123)
-- Hash generated with PHP password_hash('Admin@123', PASSWORD_DEFAULT)
-- CHANGE THIS PASSWORD immediately after your first login.
-- ---------------------------------------------------------------
INSERT INTO users (full_name, username, password)
VALUES (
  'System Owner',
  'admin',
  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'
);
