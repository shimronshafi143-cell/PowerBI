<?php
require_once __DIR__ . '/config/config.php';

if (is_logged_in()) {
    redirect('dashboard.php');
}

$errors  = [];
$success = get_flash('success');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        $errors[] = 'Invalid form submission. Please try again.';
    } else {
        $username = clean_input($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $ip       = client_ip();

        if ($username === '' || $password === '') {
            $errors[] = 'Username and password are required.';
        } else {
            // ---- Rate limiting / temporary lockout ----
            $recentFails = get_recent_failed_attempts($pdo, $username, $ip);

            if ($recentFails >= MAX_LOGIN_ATTEMPTS) {
                $errors[] = 'Too many failed attempts. Please try again in ' . LOCKOUT_MINUTES . ' minutes.';
            } else {
                // ---- Look up the (single) user with a prepared statement ----
                $stmt = $pdo->prepare('SELECT * FROM users WHERE username = :u LIMIT 1');
                $stmt->execute([':u' => $username]);
                $user = $stmt->fetch();

                if ($user && password_verify($password, $user['password'])) {
                    // ---- Success: regenerate session id to prevent fixation ----
                    session_regenerate_id(true);

                    $_SESSION['user_id']   = $user['id'];
                    $_SESSION['full_name'] = $user['full_name'];
                    $_SESSION['username']  = $user['username'];

                    log_login_attempt($pdo, $username, $ip, true);
                    clear_login_attempts($pdo, $username, $ip);

                    redirect('dashboard.php');
                } else {
                    // ---- Generic error: never reveal which field was wrong ----
                    log_login_attempt($pdo, $username, $ip, false);
                    $errors[] = 'Username or password is incorrect.';
                }
            }
        }
    }
}

$pageTitle = 'Login';
include __DIR__ . '/includes/header.php';
?>

<div class="row justify-content-center">
  <div class="col-md-5">
    <div class="card shadow-sm">
      <div class="card-body p-4">
        <h3 class="mb-4 text-center">Login</h3>

        <?php if ($success): ?>
          <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <?php if (!empty($_GET['timeout'])): ?>
          <div class="alert alert-warning">Your session expired. Please log in again.</div>
        <?php endif; ?>

        <?php foreach ($errors as $error): ?>
          <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endforeach; ?>

        <form method="POST" action="login.php" novalidate>
          <?= csrf_field() ?>

          <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" name="username" class="form-control" required
                   value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
          </div>

          <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" required>
          </div>

          <div class="d-flex justify-content-between mb-3">
            <a href="forgot_password.php">Forgot password?</a>
          </div>

          <button type="submit" class="btn btn-primary w-100">Login</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
